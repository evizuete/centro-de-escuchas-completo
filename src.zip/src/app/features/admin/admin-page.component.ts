import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule, DatePipe, DecimalPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import {
  AdminApiService,
  CallError,
  DailyCostRow,
  PipelineStatus,
} from '../../core/services/admin-api.service';
import { IconComponent } from '../../shared/components/icon.component';
import { TagComponent } from '../../shared/components/tag.component';

@Component({
  selector: 'app-admin-page',
  standalone: true,
  imports: [CommonModule, DatePipe, DecimalPipe, RouterLink, IconComponent, TagComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="page">
      <header class="page__header">
        <div>
          <h1 class="page__title">Administración</h1>
          <div class="page__subtitle">Estado del pipeline, errores recientes y coste</div>
        </div>
        <div style="display: flex; gap: 10px; align-items: center;">
          <a
              routerLink="/admin/pipeline-health"
              class="btn"
              style="background: #fff; color: #334155; border: 1px solid #cbd5e1;
                   text-decoration: none; font-weight: 500;"
              title="Ver eventos detallados del pipeline (WARN, ERROR, parse errors, etc.)"
          >
            <app-icon name="sparkles" [size]="14" />
            Ver eventos del pipeline
            <span style="margin-left: 2px; color: #6366f1;">→</span>
          </a>
          <button type="button" class="btn" (click)="refreshAll()" [disabled]="loadingStatus() || loadingErrors() || loadingCost()">
            <app-icon name="sparkles" [size]="14" /> Refrescar
          </button>
        </div>
      </header>

      <!-- ======================================================== -->
      <!-- SECCIÓN 1 · Estado del pipeline                            -->
      <!-- ======================================================== -->
      <div class="card" style="margin-bottom: 18px;">
        <div class="card__header">
          <div>
            <h3 class="card__title">Estado del pipeline</h3>
            <div class="card__subtitle">Cola actual + salud por fase (últimas 24h)</div>
          </div>
        </div>

        @if (loadingStatus()) {
          <div style="padding: 20px; text-align: center; color: #64748b;">Cargando estado…</div>
        } @else if (errorStatus()) {
          <div style="padding: 20px; text-align: center; color: #dc2626;">{{ errorStatus() }}</div>
        } @else {
          @if (status(); as s) {
            <div class="kpis" style="grid-template-columns: repeat(4, 1fr); padding: 0;">
              <div class="kpi-card">
                <div style="font-size: 10.5px; color: #64748b; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase;">Pendientes</div>
                <div style="font-size: 28px; font-weight: 700; color: #0f172a; margin-top: 6px; font-feature-settings: 'tnum';">{{ s.pending | number }}</div>
              </div>
              <div class="kpi-card">
                <div style="font-size: 10.5px; color: #64748b; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase;">Procesando</div>
                <div style="font-size: 28px; font-weight: 700; color: #3b82f6; margin-top: 6px; font-feature-settings: 'tnum';">{{ s.processing | number }}</div>
              </div>
              <div class="kpi-card">
                <div style="font-size: 10.5px; color: #64748b; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase;">Completadas hoy</div>
                <div style="font-size: 28px; font-weight: 700; color: #15803d; margin-top: 6px; font-feature-settings: 'tnum';">{{ s.completed_today | number }}</div>
              </div>
              <div class="kpi-card" [style.borderColor]="s.errors_today > 0 ? '#fecaca' : null" [style.background]="s.errors_today > 0 ? '#fffbfb' : null">
                <div style="font-size: 10.5px; color: #64748b; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase;">Errores hoy</div>
                <div style="font-size: 28px; font-weight: 700; margin-top: 6px; font-feature-settings: 'tnum';"
                     [style.color]="s.errors_today > 0 ? '#dc2626' : '#0f172a'">{{ s.errors_today | number }}</div>
              </div>
            </div>

            @if (s.phases_health.length > 0) {
              <div style="margin-top: 18px; overflow: auto;">
                <table style="width: 100%; font-size: 13px; border-collapse: collapse;">
                  <thead>
                  <tr style="font-size: 10.5px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600;">
                    <th style="text-align: left; padding: 8px 12px;">Fase</th>
                    <th style="text-align: left; padding: 8px 12px;">Estado</th>
                    <th style="text-align: right; padding: 8px 12px;">Eventos</th>
                    <th style="text-align: right; padding: 8px 12px;">Duración media</th>
                    <th style="text-align: right; padding: 8px 12px;">Coste total</th>
                  </tr>
                  </thead>
                  <tbody>
                    @for (p of s.phases_health; track $index) {
                      <tr style="border-top: 1px solid #f1f5f9;">
                        <td style="padding: 10px 12px; font-family: monospace; font-size: 12px; color: #0f172a;">{{ p.phase }}</td>
                        <td style="padding: 10px 12px;">
                          <app-tag [variant]="phaseTagVariant(p.status)">{{ p.status }}</app-tag>
                        </td>
                        <td style="padding: 10px 12px; text-align: right; font-feature-settings: 'tnum';">{{ p.events | number }}</td>
                        <td style="padding: 10px 12px; text-align: right; font-feature-settings: 'tnum'; color: #475569;">
                          @if (p.avg_duration_ms != null) {
                            {{ p.avg_duration_ms | number: '1.0-0' }} ms
                          } @else {
                            <span style="color: #cbd5e1;">—</span>
                          }
                        </td>
                        <td style="padding: 10px 12px; text-align: right; font-feature-settings: 'tnum';">
                          @if (p.total_cost_usd != null) {
                            \${{ p.total_cost_usd | number: '1.4-4' }}
                          } @else {
                            <span style="color: #cbd5e1;">—</span>
                          }
                        </td>
                      </tr>
                    }
                  </tbody>
                </table>
              </div>
            } @else {
              <div style="padding: 16px; text-align: center; color: #94a3b8; font-size: 12px;">Sin actividad de fases en las últimas 24 horas.</div>
            }
          }
        }
      </div>

      <!-- ======================================================== -->
      <!-- SECCIÓN 2 · Errores recientes                             -->
      <!-- ======================================================== -->
      <div class="card" style="margin-bottom: 18px;">
        <div class="card__header">
          <div>
            <h3 class="card__title">Errores recientes</h3>
            <div class="card__subtitle">Llamadas con status='error' · {{ errors().length }} mostradas</div>
          </div>
          <a
              routerLink="/admin/pipeline-health"
              style="font-size: 12px; color: #6366f1; text-decoration: none; font-weight: 500;"
              title="Ver eventos WARN/ERROR del pipeline con detalle JSON"
          >
            Ver eventos detallados →
          </a>
        </div>

        @if (loadingErrors()) {
          <div style="padding: 20px; text-align: center; color: #64748b;">Cargando errores…</div>
        } @else if (errorErrors()) {
          <div style="padding: 20px; text-align: center; color: #dc2626;">{{ errorErrors() }}</div>
        } @else if (errors().length === 0) {
          <div style="padding: 24px; text-align: center; color: #94a3b8; font-size: 13px;">
            <app-icon name="sparkles" [size]="20" color="#15803d" />
            <div style="margin-top: 6px;">Sin errores pendientes. Pipeline saludable.</div>
          </div>
        } @else {
          <div style="overflow: auto;">
            <table style="width: 100%; font-size: 13px; border-collapse: collapse;">
              <thead>
              <tr style="font-size: 10.5px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600;">
                <th style="text-align: left; padding: 8px 12px;">Call ID</th>
                <th style="text-align: left; padding: 8px 12px;">Fase</th>
                <th style="text-align: left; padding: 8px 12px;">Mensaje</th>
                <th style="text-align: right; padding: 8px 12px;">Intentos</th>
                <th style="text-align: left; padding: 8px 12px;">Agente</th>
                <th style="text-align: left; padding: 8px 12px;">Actualizado</th>
                <th style="text-align: right; padding: 8px 12px;"></th>
              </tr>
              </thead>
              <tbody>
                @for (e of errors(); track e.call_id) {
                  <tr style="border-top: 1px solid #f1f5f9;">
                    <td style="padding: 10px 12px; font-family: monospace; font-size: 11px; color: #475569;">{{ shortId(e.call_id) }}</td>
                    <td style="padding: 10px 12px; font-family: monospace; font-size: 12px; color: #0f172a;">{{ e.current_phase ?? '—' }}</td>
                    <td style="padding: 10px 12px; font-size: 12px; color: #7f1d1d; max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"
                        [title]="e.error_message">{{ e.error_message ?? '—' }}</td>
                    <td style="padding: 10px 12px; text-align: right; font-feature-settings: 'tnum';">{{ e.retry_count }}</td>
                    <td style="padding: 10px 12px; color: #64748b;">{{ e.final_agent ?? '—' }}</td>
                    <td style="padding: 10px 12px; color: #64748b; font-size: 12px;">{{ e.updated_at | date: 'dd/MM HH:mm' }}</td>
                    <td style="padding: 10px 12px; text-align: right;">
                      <button
                          type="button"
                          class="btn"
                          [disabled]="retryingId() === e.call_id"
                          (click)="confirmRetry(e.call_id)"
                          style="font-size: 11px; padding: 4px 10px;"
                      >
                        @if (retryingId() === e.call_id) {
                          Reintentando…
                        } @else {
                          Reintentar
                        }
                      </button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </div>

      <!-- ======================================================== -->
      <!-- SECCIÓN 3 · Coste diario                                  -->
      <!-- ======================================================== -->
      <div class="card">
        <div class="card__header">
          <div>
            <h3 class="card__title">Coste diario</h3>
            <div class="card__subtitle">Agregado × fase · últimos {{ costDays() }} días · total \${{ totalCost() | number: '1.2-2' }}</div>
          </div>
          <div class="seg" style="font-size: 11px;">
            @for (d of costRanges; track d) {
              <button type="button" class="seg__btn"
                      [class.seg__btn--active]="costDays() === d"
                      (click)="setCostDays(d)">
                {{ d }}d
              </button>
            }
          </div>
        </div>

        @if (loadingCost()) {
          <div style="padding: 20px; text-align: center; color: #64748b;">Cargando coste…</div>
        } @else if (errorCost()) {
          <div style="padding: 20px; text-align: center; color: #dc2626;">{{ errorCost() }}</div>
        } @else if (costRows().length === 0) {
          <div style="padding: 20px; text-align: center; color: #94a3b8; font-size: 13px;">Sin datos de coste en este rango.</div>
        } @else {
          <div style="overflow: auto;">
            <table style="width: 100%; font-size: 13px; border-collapse: collapse;">
              <thead>
              <tr style="font-size: 10.5px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600;">
                <th style="text-align: left; padding: 8px 12px;">Día</th>
                <th style="text-align: left; padding: 8px 12px;">Fase</th>
                <th style="text-align: right; padding: 8px 12px;">Eventos</th>
                <th style="text-align: right; padding: 8px 12px;">Tokens in</th>
                <th style="text-align: right; padding: 8px 12px;">Tokens out</th>
                <th style="text-align: right; padding: 8px 12px;">Tokens cached</th>
                <th style="text-align: right; padding: 8px 12px;">Coste</th>
              </tr>
              </thead>
              <tbody>
                @for (row of costRows(); track $index) {
                  <tr style="border-top: 1px solid #f1f5f9;">
                    <td style="padding: 8px 12px; font-feature-settings: 'tnum'; color: #475569;">{{ row.day }}</td>
                    <td style="padding: 8px 12px; font-family: monospace; font-size: 12px; color: #0f172a;">{{ row.phase }}</td>
                    <td style="padding: 8px 12px; text-align: right; font-feature-settings: 'tnum';">{{ row.events | number }}</td>
                    <td style="padding: 8px 12px; text-align: right; font-feature-settings: 'tnum'; color: #64748b;">{{ (row.tokens_in ?? 0) | number }}</td>
                    <td style="padding: 8px 12px; text-align: right; font-feature-settings: 'tnum'; color: #64748b;">{{ (row.tokens_out ?? 0) | number }}</td>
                    <td style="padding: 8px 12px; text-align: right; font-feature-settings: 'tnum'; color: #64748b;">{{ (row.tokens_cached ?? 0) | number }}</td>
                    <td style="padding: 8px 12px; text-align: right; font-feature-settings: 'tnum'; font-weight: 600;">\${{ (row.cost ?? 0) | number: '1.4-4' }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </div>
    </div>
  `,
})
export class AdminPageComponent {
  private api = inject(AdminApiService);

  // --- Pipeline status -----------------------------------------------------
  readonly status = signal<PipelineStatus | null>(null);
  readonly loadingStatus = signal<boolean>(true);
  readonly errorStatus = signal<string | null>(null);

  // --- Errors --------------------------------------------------------------
  readonly errors = signal<CallError[]>([]);
  readonly loadingErrors = signal<boolean>(true);
  readonly errorErrors = signal<string | null>(null);
  readonly retryingId = signal<string | null>(null);

  // --- Cost ----------------------------------------------------------------
  readonly costRows = signal<DailyCostRow[]>([]);
  readonly loadingCost = signal<boolean>(true);
  readonly errorCost = signal<string | null>(null);
  readonly costDays = signal<number>(30);
  readonly costRanges = [7, 30, 90];
  readonly totalCost = computed(() =>
      this.costRows().reduce((acc, r) => acc + (r.cost ?? 0), 0)
  );

  constructor() {
    this.refreshAll();
  }

  refreshAll(): void {
    this.loadStatus();
    this.loadErrors();
    this.loadCost();
  }

  setCostDays(d: number): void {
    this.costDays.set(d);
    this.loadCost();
  }

  confirmRetry(callId: string): void {
    const ok = typeof window !== 'undefined'
        ? window.confirm(`¿Reencolar la llamada ${callId}? Se resetea retry_count y error_message.`)
        : true;
    if (!ok) return;
    this.retryingId.set(callId);
    this.api.retryCall(callId).subscribe({
      next: () => {
        this.retryingId.set(null);
        // Quitamos la fila de la tabla localmente y recargamos status.
        this.errors.update((xs) => xs.filter((x) => x.call_id !== callId));
        this.loadStatus();
      },
      error: (err) => {
        this.retryingId.set(null);
        console.error('[admin] retry error', err);
        if (typeof window !== 'undefined') {
          window.alert('No se pudo reintentar. Revisa la consola.');
        }
      },
    });
  }

  phaseTagVariant(status: string): 'green' | 'amber' | 'red' | 'gray' {
    const s = status.toLowerCase();
    if (s === 'success' || s === 'completed' || s === 'ok') return 'green';
    if (s === 'error' || s === 'failed') return 'red';
    if (s === 'warning' || s === 'retrying') return 'amber';
    return 'gray';
  }

  shortId(id: string): string {
    return id.length > 12 ? id.substring(0, 12) + '…' : id;
  }

  private loadStatus(): void {
    this.loadingStatus.set(true);
    this.errorStatus.set(null);
    this.api.getPipelineStatus().subscribe({
      next: (s) => { this.status.set(s); this.loadingStatus.set(false); },
      error: (err) => {
        this.loadingStatus.set(false);
        this.errorStatus.set('No se pudo cargar el estado del pipeline');
        console.error('[admin] status error', err);
      },
    });
  }

  private loadErrors(): void {
    this.loadingErrors.set(true);
    this.errorErrors.set(null);
    this.api.getRecentErrors(50).subscribe({
      next: (xs) => { this.errors.set(xs); this.loadingErrors.set(false); },
      error: (err) => {
        this.loadingErrors.set(false);
        this.errorErrors.set('No se pudieron cargar los errores');
        console.error('[admin] errors error', err);
      },
    });
  }

  private loadCost(): void {
    this.loadingCost.set(true);
    this.errorCost.set(null);
    this.api.getDailyCost(this.costDays()).subscribe({
      next: (xs) => { this.costRows.set(xs); this.loadingCost.set(false); },
      error: (err) => {
        this.loadingCost.set(false);
        this.errorCost.set('No se pudo cargar el coste');
        console.error('[admin] cost error', err);
      },
    });
  }
}
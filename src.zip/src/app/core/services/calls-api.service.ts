import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from '../../environments/environment';
import {DetalleLlamada, Llamada, Nota, NotaCreate} from '../models/domain.models';

/**
 * Paginación estándar del backend.
 *
 * El backend usa snake_case (page_size) mientras que el frontend ya
 * esperaba un shape similar — se respeta el original.
 */
export interface PagedLlamadas {
  total: number;
  page: number;
  page_size: number;
  items: Llamada[];
}

/** Filtros que acepta GET /api/calls. Todos son opcionales. */
export interface CallsListFilter {
  from?: string;                 // ISO datetime
  to?: string;                   // ISO datetime
  agente?: string;
  categoria?: string;
  tipo?: string;
  estado?: string;
  sentimiento?: string;
  no_leidas?: boolean;
  pinned?: boolean;
  has_event_type?: string;       // drill-down desde pipeline-health
  event_phase?: string;
  page?: number;                 // default 1
  page_size?: number;            // default 25, máx 200
  sort_by?: 'call_timestamp' | 'call_health_score' | 'agent_quality_score' | 'facturacion_eur';
  sort_dir?: 'asc' | 'desc';
}

/** Estado de revisión UI aceptado por PATCH /api/calls/{id}/estado. */
export type CallEstado = 'A REVISAR' | 'EN REVISIÓN' | 'REVISADO' | 'NO APLICA';

/** Fila simplificada que devuelve GET /api/calls/search/text. */
export interface CallSearchHit {
  call_id: string;
  call_timestamp: string;
  final_agent: string;
  categoria: string;
  sentiment_final: string;
  call_health_score: number;
  contact_name: string;
  rel: number;
}

@Injectable({ providedIn: 'root' })
export class CallsApiService {
  private http = inject(HttpClient);
  private base = environment.apiUrl;

  /**
   * Listado paginado de llamadas con los filtros de la UI.
   *
   * Los filtros se propagan como query-params tal cual al backend. Para
   * compatibilidad con la vista actual, lo típico es pedir un page_size
   * grande (p. ej. 200) y seguir haciendo filtrado fino en cliente; el
   * día que el volumen lo exija se activan los filtros de servidor.
   */
  list(filter: CallsListFilter = {}): Observable<PagedLlamadas> {
    let params = new HttpParams();
    for (const [k, v] of Object.entries(filter)) {
      if (v === undefined || v === null || v === '') continue;
      params = params.set(k, String(v));
    }
    return this.http.get<PagedLlamadas>(`${this.base}/api/calls`, { params });
  }

  /** Detalle completo de una llamada — alimenta la vista de detalle. */
  getDetail(callId: string): Observable<DetalleLlamada> {
    return this.http.get<DetalleLlamada>(
      `${this.base}/api/calls/${encodeURIComponent(callId)}`,
    );
  }

  /**
   * Actualiza el estado de revisión (A REVISAR / EN REVISIÓN / ...).
   * Nota: el backend espera PATCH con `estado` como query-param.
   */
  updateEstado(callId: string, estado: CallEstado): Observable<{ call_id: string; estado: CallEstado }> {
    const params = new HttpParams().set('estado', estado);
    return this.http.patch<{ call_id: string; estado: CallEstado }>(
      `${this.base}/api/calls/${encodeURIComponent(callId)}/estado`,
      null,
      { params },
    );
  }

  /** Marca/desmarca como pinneada. PATCH con `pinned` como query-param. */
  togglePinned(callId: string, pinned: boolean): Observable<{ call_id: string; pinned: boolean }> {
    const params = new HttpParams().set('pinned', String(pinned));
    return this.http.patch<{ call_id: string; pinned: boolean }>(
      `${this.base}/api/calls/${encodeURIComponent(callId)}/pinned`,
      null,
      { params },
    );
  }

  /** Búsqueda FULLTEXT sobre transcripciones. Mínimo 3 chars. */
  searchText(q: string, limit = 20): Observable<CallSearchHit[]> {
    const params = new HttpParams().set('q', q).set('limit', String(limit));
    return this.http.get<CallSearchHit[]>(`${this.base}/api/calls/search/text`, {
      params,
    });
  }

  /** Lista las notas asociadas a una llamada (orden cronológico desc). */
  getNotes(callId: string): Observable<Nota[]> {
    return this.http.get<Nota[]>(`${this.base}/api/calls/${callId}/notes`);
  }

  /** Crea una nota nueva. Devuelve la nota persistida con id y fecha del server. */
  addNote(callId: string, payload: NotaCreate): Observable<Nota> {
    return this.http.post<Nota>(`${this.base}/api/calls/${callId}/notes`, payload);
  }

}



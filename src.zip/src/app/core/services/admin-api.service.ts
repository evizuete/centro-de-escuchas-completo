import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from '../../environments/environment';

/** Salud agregada de una fase del pipeline (ventana últimas 24h). */
export interface PhaseHealth {
  phase: string;
  status: string;
  events: number;
  avg_duration_ms: number | null;
  total_cost_usd: number | null;
}

/** Snapshot global del estado del pipeline. */
export interface PipelineStatus {
  pending: number;
  processing: number;
  completed_today: number;
  errors_today: number;
  phases_health: PhaseHealth[];
}

/** Llamada que está actualmente en estado='error' en la cola. */
export interface CallError {
  call_id: string;
  status: string;
  current_phase: string | null;
  error_message: string | null;
  retry_count: number;
  updated_at: string;    // ISO datetime
  final_agent: string | null;
}

/** Respuesta de POST /api/admin/calls/{id}/retry. */
export interface RetryResult {
  call_id: string;
  status: string;
}

/** Fila del agregado diario de coste × fase. */
export interface DailyCostRow {
  day: string;           // ISO date (YYYY-MM-DD)
  phase: string;
  cost: number | null;
  events: number;
  tokens_in: number | null;
  tokens_out: number | null;
  tokens_cached: number | null;
}

@Injectable({ providedIn: 'root' })
export class AdminApiService {
  private http = inject(HttpClient);
  private base = environment.apiUrl;

  /** Estado global: contadores de la cola y agregado por fase. */
  getPipelineStatus(): Observable<PipelineStatus> {
    return this.http.get<PipelineStatus>(`${this.base}/api/admin/pipeline/status`);
  }

  /**
   * Últimas llamadas en estado='error'.
   * @param limit 1-500, default 50
   */
  getRecentErrors(limit = 50): Observable<CallError[]> {
    const params = new HttpParams().set('limit', String(limit));
    return this.http.get<CallError[]>(`${this.base}/api/admin/errors`, { params });
  }

  /**
   * Reencola una llamada errónea (status → 'pending', retry_count → 0).
   * Operación de administración: idealmente pedir confirmación al usuario
   * antes de llamarla.
   */
  retryCall(callId: string): Observable<RetryResult> {
    return this.http.post<RetryResult>(
      `${this.base}/api/admin/calls/${encodeURIComponent(callId)}/retry`,
      null,
    );
  }

  /**
   * Agregado diario de coste × fase.
   * @param days 1-365, default 30
   */
  getDailyCost(days = 30): Observable<DailyCostRow[]> {
    const params = new HttpParams().set('days', String(days));
    return this.http.get<DailyCostRow[]>(`${this.base}/api/admin/cost/daily`, { params });
  }
}

import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from '../../environments/environment';
import { Agente, AgenteInsights, Supervisor } from '../models/domain.models';

/** Filtros opcionales para GET /api/agents. */
export interface AgentsListFilter {
  supervisor_id?: string;
  country?: string;
}

@Injectable({ providedIn: 'root' })
export class SupervisorsApiService {
  private http = inject(HttpClient);
  private base = environment.apiUrl;

  /** Lista completa de supervisores con sus KPIs agregados (30d). */
  listSupervisors(): Observable<Supervisor[]> {
    return this.http.get<Supervisor[]>(`${this.base}/api/supervisors`);
  }

  /** Detalle de un supervisor. */
  getSupervisor(id: string): Observable<Supervisor> {
    return this.http.get<Supervisor>(
      `${this.base}/api/supervisors/${encodeURIComponent(id)}`,
    );
  }

  /**
   * Lista de agentes con stats enriquecidos (foto, facturación, idiomas,
   * tendencia, topTemas, resolucionMedia).
   *
   * Filtros opcionales:
   *   - supervisor_id: agentes de un equipo concreto
   *   - country: filtro por país
   */
  listAgents(filter: AgentsListFilter = {}): Observable<Agente[]> {
    let params = new HttpParams();
    if (filter.supervisor_id) params = params.set('supervisor_id', filter.supervisor_id);
    if (filter.country) params = params.set('country', filter.country);
    return this.http.get<Agente[]>(`${this.base}/api/agents`, { params });
  }

  /**
   * Insights del agente. **Nota**: el shape actual del backend todavía no
   * cubre todos los campos que la UI pide (`mejoras`, `momentosBrillantes`,
   * `patronesRiesgo`, `coachingRecibido`). Los componentes deben tratarlos
   * como opcionales.
   */
  getAgentInsights(agentId: string): Observable<AgenteInsights> {
    return this.http.get<AgenteInsights>(
      `${this.base}/api/agents/${encodeURIComponent(agentId)}/insights`,
    );
  }
}

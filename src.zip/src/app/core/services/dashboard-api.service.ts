import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from '../../environments/environment';
import { DashboardData } from '../models/domain.models';

/**
 * Periodos aceptados por el frontend (en español, legibles en UI).
 *
 * El backend expone /api/dashboard?period= con los valores
 * 'day' | 'week' | 'month' | 'quarter' — el service se encarga del mapeo
 * para que los componentes puedan seguir razonando en español.
 */
export type DashboardPeriod = 'hoy' | 'semana' | 'mes' | 'trimestre';

const PERIOD_TO_API: Record<DashboardPeriod, string> = {
  hoy: 'day',
  semana: 'week',
  mes: 'month',
  trimestre: 'quarter',
};

@Injectable({ providedIn: 'root' })
export class DashboardApiService {
  private http = inject(HttpClient);
  private base = environment.apiUrl;

  /**
   * Devuelve el payload completo del dashboard para el periodo indicado.
   *
   * El shape de la respuesta está diseñado espejo de MOCK_DASHBOARD, por lo
   * que puede sustituir directamente al signal estático del DataService.
   *
   * Nota: `detalleLlamada` siempre llega a null; el detalle se solicita
   * por separado con GET /api/calls/{id}.
   */
  getDashboard(period: DashboardPeriod = 'semana'): Observable<DashboardData> {
    const params = new HttpParams().set('period', PERIOD_TO_API[period]);
    return this.http.get<DashboardData>(`${this.base}/api/dashboard`, {
      params,
    });
  }
}
